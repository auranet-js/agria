# AGRIA — repozytorium projektowe Auranet

> Baza wiedzy, strategii, audytów i materiałów marketingowych dla klienta **AGRIA Sp. z o.o.** (marka Agrobielik, 35 lat na rynku surowców wapniowych).

## Skład repo

- `CLAUDE.md` — plik startowy dla Claude Code (czytany automatycznie).
- `docs/` — cała dokumentacja (markdown).
- `assets/` — pliki binarne: logo, JSX do InDesign, źródła katalogu drukowanego.

## Jak zacząć

### Klonowanie

```bash
git clone git@github.com:auranet-js/agria.git
cd agria
```

### Praca w Claude Code

```bash
claude
# w sesji:
/init
```

Claude przeczyta `CLAUDE.md` → `docs/MASTER_PROMPT.md` → `docs/PROJECT_STATE.md` i będzie gotowy do pracy zgodnie z rolą strategicznego partnera marketingowego AGRIA.

## Mapa dokumentów

| Katalog          | Co zawiera                                                    |
|------------------|---------------------------------------------------------------|
| `docs/strategy/` | Strategia marketingowa 2025–2026, budżet, KPI                |
| `docs/seo/`      | Plan audytu, oferta 6-miesięczna, baseline słów kluczowych   |
| `docs/catalog/`  | Stan WooCommerce, katalog drukowany, mapowanie danych        |
| `docs/brand/`    | Identyfikacja wizualna                                        |
| `docs/technical/`| Infrastruktura, MCP, narzędzia                                |
| `docs/offers/`   | Treści ofert dla klienta                                      |
| `docs/operations/` | Working agreement, procesy                                 |

## Zasady commitowania

- **Branche tematyczne**: `feature/...`, `audit/...`, `offer/...`
- **Brak sekretów w repo** — żadnych haseł FTP, kluczy API, dostępów.
- Commit messages po polsku, krótkie i konkretne.
- PR review przed mergem do `main` (przynajmniej self-review).

## Kontakt operacyjny

- Klient: AGRIA Sp. z o.o., biuro@agria.pl, +48 660 768 691
- Wykonawca: Auranet
- Strona produkcyjna: https://agria.pl (nazwa.pl, serwer371853)
