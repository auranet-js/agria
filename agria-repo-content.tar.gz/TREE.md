# Drzewo repo agria/ — zawartość po wgraniu

```
agria/
├── .gitignore
├── CLAUDE.md                                    ← startowy plik dla Claude Code
├── README.md                                    ← opis repo dla człowieka
├── assets/
│   ├── AGRIA_DUPLIKUJ_AGROBIELIK70_v3.jsx       ← wzór JSX karty katalogu
│   ├── KATALOG_AGRIA_24STR_KOMPLET.txt          ← pełna spec katalogu (źródło)
│   └── agria-logo.png                           ← logo
└── docs/
    ├── MASTER_PROMPT.md                         ← tożsamość Claude'a w projekcie
    ├── PROJECT_STATE.md                         ← bieżący stan, decyzje, otwarte pytania
    ├── brand/
    │   └── IDENTITY.md                          ← logo, paleta, fonty, ToV
    ├── catalog/
    │   ├── DESIGN_SPEC.md                       ← spec graficzna katalogu
    │   ├── EXTENDSCRIPT_RULES.md                ← reguły InDesign/JSX (gotchas)
    │   ├── PRINT_CATALOG_SPEC.md                ← spec katalogu 24str
    │   ├── PRODUCTS_INVENTORY.md                ← stan WC (live z MCP, 19 produktów)
    │   └── PRODUCT_DATA_MAPPING.md              ← mapowanie WC → druk
    ├── offers/
    │   └── AURANET_2000PLN_MONTHLY.md           ← oferta 6-miesięczna dla klienta
    ├── operations/
    │   └── WORKING_AGREEMENT.md                 ← zasady współpracy Auranet↔AGRIA
    ├── seo/
    │   ├── KEYWORDS_BASELINE.md                 ← lista fraz (szkielet)
    │   └── SEO_AUDIT_PLAN.md                    ← plan audytu (Q2 2026, Auranet free)
    ├── strategy/
    │   ├── BUDGET_KPI.md                        ← budżet kwartalny + KPI definicje
    │   └── STRATEGY_2025_2026.md                ← kompresja strategii .docx
    └── technical/
        ├── INFRASTRUCTURE.md                    ← stack, hosting, dostępy (placeholdery)
        └── MCP_TOOLS.md                         ← narzędzia MCP Agria.pl
```

**Łącznie: 22 pliki** (Markdown × 18, asset × 3, .gitignore × 1).

---

## Co jeszcze może dojść w przyszłości (puste foldery na razie)

- `docs/seo/SEO_AUDIT_RESULTS.md` — po wykonaniu audytu
- `docs/seo/CONTENT_CALENDAR.md` — kalendarz publikacji blogowych
- `docs/strategy/LANDING_PAGES_OUTLINES.md` — outline'y LP rolnicy/oczyszczalnie/stawy
- `docs/technical/SECURITY_AUDIT.md` — audyt wtyczek WP
- `assets/jsx/` — folder na 17 generowanych kart katalogu
- `docs/reports/2026-06.md`, `docs/reports/2026-07.md` itd. — comiesięczne raporty
```
